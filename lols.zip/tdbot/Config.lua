do
local _ = {
		SUDO = 495075126,
		sudoidforpanel = 495075126,
		cliidforpanel = 517572874,
        SUDO_ID = {495075126,533431832,517572874},
		sudoapibot = {495075126,517572874},
        Full_Sudo = {495075126,533431832,517572874},
        ChannelLogs= '@Dream_Producer',
		token = '533431832:AAHmzB4O5qttcH0kx46oUooTOYPSQbNC9Eo',
        TokenApibot = '488611771:AAGUy7rZH2Bo_CdxRLTx7ztebit3XDbVkCM',
        ChannelUsername = '@Ulterahelp',
        Channelforcejoin = '@Ulterahelp',
	    Sudousernameapi = 'Dream_Producer',
        Channelusernameapi = 'Ulterahelp',
        Botusernameapi = 'Ultera_knight',
		salechannelbot = 'Dream_Producer',
        Pardakht = 'https://t.me/joinchat/HYI_Nkblcx4RbNduLfAm2w',
        Botusernamelink = 'Ultera_knight',
        Sendpayiduser = 495075126,
        apipanelbotuserid = 533431832,
        Channelnameauto = 'ربات مدیریت گروه',
}
return _
end
