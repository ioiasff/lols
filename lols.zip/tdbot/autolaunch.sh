#!/bin/bash
COUNTER=1
while(true) do
./launch run
curl "https://api.telegram.org/bot528269709:AAGBqk_UjxR9DI9KaP3r79mG43F0pO_zDoo/sendmessage" -F "chat_id=159887854" -F "text=#NEWCRASH-#BOT-Reloaded-${COUNTER}-times"
let COUNTER=COUNTER+1 
done
